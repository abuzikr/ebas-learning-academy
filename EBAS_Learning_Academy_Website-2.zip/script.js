document.getElementById("year").textContent = new Date().getFullYear();

function toggleMenu(){
  const nav=document.getElementById("nav");
  nav.style.display = nav.style.display==="flex" ? "none" : "flex";
}

function openClass(level){
  const content=document.getElementById("modal-content");
  content.innerHTML=`
    <h2>JSS ${level} Learning Centre</h2>
    <p>Welcome to JSS ${level}. Choose a subject to begin your learning journey.</p>
    <div style="display:grid;gap:10px;margin-top:20px">
      <button class="start" onclick="showMessage('JSS ${level} Mathematics content is ready to be added.')">🔢 Mathematics</button>
      <button class="start" onclick="showMessage('JSS ${level} Integrated Science content is ready to be added.')">🔬 Integrated Science</button>
    </div>`;
  document.getElementById("modal").classList.add("show");
}

function showMessage(message){
  document.getElementById("modal-content").innerHTML=`
    <h2>Coming Next</h2>
    <p>${message}</p>
    <p style="margin-top:12px;color:#66736b">The next development stage will add the full lessons, notes, exercises and tests.</p>`;
  document.getElementById("modal").classList.add("show");
}

function closeModal(event){
  if(!event || event.target.id==="modal"){
    document.getElementById("modal").classList.remove("show");
  }
}
