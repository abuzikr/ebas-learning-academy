EBAS LEARNING ACADEMY
=====================

This is the first working website version for:
- JSS 1 Mathematics
- JSS 1 Integrated Science
- JSS 2 Mathematics
- JSS 2 Integrated Science
- JSS 3 Mathematics
- JSS 3 Integrated Science

FILES
-----
index.html  = website structure
style.css   = design and mobile responsiveness
script.js   = buttons, class selector and popup functions

HOW TO TEST
-----------
Open index.html in a web browser.

HOW TO PUBLISH
--------------
Upload all three files to a web hosting service. Keep them in the same folder.
The host will give you a public HTTPS URL. That URL can then be entered into a
Web-to-App converter.

NEXT DEVELOPMENT
-----------------
The buttons currently act as placeholders. The next version can add the actual
JSS curriculum, lesson notes, quizzes, automatic marking, results and student
accounts.
